#!/bin/bash
set -e
echo ""
echo "==================================="
echo "Helper Harry Print Floor Agent"
echo "==================================="
echo ""

if ! command -v node >/dev/null 2>&1; then
  echo "ERROR: Node.js is not installed."
  echo "Install Node.js 18+ from https://nodejs.org and run this again."
  exit 1
fi

echo "Installing dependencies..."
npm install --production

echo ""
echo "Starting first-time setup..."
node src/index.js --setup

echo ""
echo "Setup complete. Starting agent (press Ctrl+C to stop)..."
node src/index.js
