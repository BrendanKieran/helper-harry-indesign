# Helper Harry Print Floor Agent

A small background program that watches the Helper Harry cloud for
print-ready jobs and downloads their files to organised folders on
your shop-floor PC, so approved proofs appear automatically in a
watched folder ready to RIP.

## Requirements

- **Node.js 18 or later** — download from <https://nodejs.org> and install (pick the LTS version)
- Helper Harry login with Workflow access

## Install

### Windows

1. Extract this ZIP anywhere (e.g. `C:\Helper-Harry\Print-Floor-Agent`)
2. Double-click **install.bat**. It will:
   - Check Node is installed
   - Install the agent's dependencies
   - Run the first-time setup (asks for your login, the watched folder, polling interval)
3. Leave the window open — the agent is now watching.

To start the agent again after a reboot: double-click **start.bat** in the same folder.

To have the agent start automatically on login, press **Win+R**, type `shell:startup`, and drag `start.bat` into that folder.

### macOS / Linux

1. Extract the ZIP anywhere
2. Open Terminal in the extracted folder
3. Run:
   ```
   chmod +x install.sh start.sh
   ./install.sh
   ```
   Follow the prompts.
4. Leave the terminal window open.

To start again later: `./start.sh` in the same folder.

## What the agent does

- Polls Helper Harry every N minutes (you set this at install — default 5)
- Finds any job marked ready with print-ready files
- Downloads each file into your watched folder using the naming scheme
  you picked (by job number, by customer, or flat)
- Keeps track of what it's already downloaded — you won't get duplicates

## Where files end up

Default: `C:\Helper-Harry\Print-Floor\JOB-XXXX\` (Windows) or
`~/Helper-Harry/Print-Floor/JOB-XXXX/` (macOS/Linux) — you can change
this during setup or by editing `config.json` in this folder.

## Troubleshooting

**"node: command not found"** — Install Node.js from <https://nodejs.org>

**"Login failed"** — Double-check you can log in at
<https://app.helperharry.com>. If your password has changed, re-run
`install.bat` / `./install.sh` to re-authenticate.

**Agent crashes or stops** — Check `agent.log` in the folder for the
error. Contact <support@helperharry.com> with the last few lines.

## Reconfigure

Delete `config.json` in this folder and re-run `install.bat` or
`./install.sh` — it will re-prompt for everything.
