/**
 * Config — loads/saves agent configuration from ~/.hh-agent/config.json
 */
const fs = require('fs-extra');
const path = require('path');
const os = require('os');
const readline = require('readline');

const CONFIG_DIR = path.join(os.homedir(), '.hh-agent');
const CONFIG_FILE = path.join(CONFIG_DIR, 'config.json');

const DEFAULTS = {
  serverUrl: '',
  email: '',
  downloadDir: path.join(os.homedir(), 'HH Print Jobs'),
  pollIntervalMs: 30000,
  watchState: 'approved',
  markStateOnDownload: '',   // optional: state to complete after all files downloaded
  folderTemplate: '{job_number} {customer} {description}',
  maxConcurrentDownloads: 3
};

function load() {
  try {
    if (fs.existsSync(CONFIG_FILE)) {
      const raw = fs.readJsonSync(CONFIG_FILE);
      return { ...DEFAULTS, ...raw };
    }
  } catch (e) { /* fall through */ }
  return { ...DEFAULTS };
}

function save(config) {
  fs.ensureDirSync(CONFIG_DIR);
  fs.writeJsonSync(CONFIG_FILE, config, { spaces: 2 });
}

function getTokenPath() {
  return path.join(CONFIG_DIR, '.token');
}

function loadToken() {
  try {
    const p = getTokenPath();
    if (fs.existsSync(p)) return fs.readFileSync(p, 'utf8').trim();
  } catch (e) { /* fall through */ }
  return null;
}

function saveToken(token) {
  fs.ensureDirSync(CONFIG_DIR);
  fs.writeFileSync(getTokenPath(), token, { mode: 0o600 });
}

function clearToken() {
  try { fs.removeSync(getTokenPath()); } catch (e) { /* ok */ }
}

// Interactive setup
async function interactiveSetup() {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  const ask = (q) => new Promise(resolve => rl.question(q, resolve));

  const config = load();
  console.log('\n  Helper Harry Print Floor Agent — Setup\n');

  config.serverUrl = (await ask(`  Server URL [${config.serverUrl || 'https://app.helperharry.com'}]: `)).trim() || config.serverUrl || 'https://app.helperharry.com';
  config.email = (await ask(`  Email [${config.email}]: `)).trim() || config.email;

  const pw = (await ask('  Password: ')).trim();

  config.downloadDir = (await ask(`  Download directory [${config.downloadDir}]: `)).trim() || config.downloadDir;

  const interval = (await ask(`  Poll interval in seconds [${config.pollIntervalMs / 1000}]: `)).trim();
  if (interval) config.pollIntervalMs = parseInt(interval, 10) * 1000;

  config.watchState = (await ask(`  Watch state name [${config.watchState}]: `)).trim() || config.watchState;

  config.markStateOnDownload = (await ask(`  Mark state after download (leave blank to skip) [${config.markStateOnDownload}]: `)).trim() || config.markStateOnDownload;

  rl.close();

  save(config);
  console.log(`\n  Config saved to ${CONFIG_FILE}`);

  return { config, password: pw };
}

module.exports = { load, save, loadToken, saveToken, clearToken, interactiveSetup, CONFIG_DIR };
