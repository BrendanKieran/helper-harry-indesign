/**
 * State Tracker — persists what's been downloaded to a local JSON file.
 * Stored in the download directory as .hh-agent-state.json
 */
const fs = require('fs-extra');
const path = require('path');

const STATE_FILENAME = '.hh-agent-state.json';

class StateTracker {
  constructor(downloadDir) {
    this.filePath = path.join(downloadDir, STATE_FILENAME);
    this.state = { lastPollTime: null, jobs: {} };
    this._load();
  }

  _load() {
    try {
      if (fs.existsSync(this.filePath)) {
        this.state = fs.readJsonSync(this.filePath);
      }
    } catch (e) { /* start fresh */ }
  }

  _save() {
    try {
      // Atomic write: write to temp then rename
      const tmp = this.filePath + '.tmp';
      fs.writeJsonSync(tmp, this.state, { spaces: 2 });
      fs.renameSync(tmp, this.filePath);
    } catch (e) {
      console.error('Failed to save state:', e.message);
    }
  }

  get lastPollTime() { return this.state.lastPollTime; }
  set lastPollTime(t) { this.state.lastPollTime = t; this._save(); }

  isFileDownloaded(jobId, fileId, version) {
    const job = this.state.jobs[jobId];
    if (!job?.files?.[fileId]) return false;
    return job.files[fileId].version >= version;
  }

  markFileDownloaded(jobId, jobNumber, folderPath, fileId, fileInfo) {
    if (!this.state.jobs[jobId]) {
      this.state.jobs[jobId] = { jobNumber, folderPath, files: {}, stateCompleted: false };
    }
    const job = this.state.jobs[jobId];
    job.folderPath = folderPath;
    job.files[fileId] = {
      version: fileInfo.version,
      filename: fileInfo.filename,
      downloadedAt: new Date().toISOString(),
      fileSize: fileInfo.fileSize
    };
    this._save();
  }

  isStateCompleted(jobId) {
    return this.state.jobs[jobId]?.stateCompleted || false;
  }

  markStateCompleted(jobId) {
    if (this.state.jobs[jobId]) {
      this.state.jobs[jobId].stateCompleted = true;
      this._save();
    }
  }
}

module.exports = StateTracker;
