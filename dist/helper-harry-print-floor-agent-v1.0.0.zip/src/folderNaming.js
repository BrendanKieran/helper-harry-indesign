/**
 * Folder Naming — builds safe folder names from job metadata
 *
 * Template tokens: {job_number} {customer} {customer_company} {description}
 * Output: "JOB-0001 Acme Corp Business Cards"
 */
const path = require('path');

// Characters unsafe for filesystem paths (Windows + Mac + Linux)
const UNSAFE_RE = /[\/\\:*?"<>|]/g;

function sanitize(str) {
  return str
    .replace(UNSAFE_RE, '_')
    .replace(/\s+/g, ' ')
    .trim()
    .substring(0, 200);
}

function buildFolderName(job, template) {
  const customer = job.customer_company
    || [job.customer_first_name, job.customer_last_name].filter(Boolean).join(' ')
    || 'Unknown';

  const tokens = {
    job_number: job.job_number || 'UNKNOWN',
    customer: customer,
    customer_company: job.customer_company || customer,
    description: job.description || ''
  };

  let name = template || '{job_number} {customer} {description}';
  for (const [key, val] of Object.entries(tokens)) {
    name = name.replace(new RegExp(`\\{${key}\\}`, 'g'), val);
  }

  return sanitize(name);
}

/**
 * Extract the job number prefix from a folder name (first token before space).
 * Used to find existing folders for resubmissions.
 */
function extractJobPrefix(folderName) {
  return folderName.split(' ')[0];
}

/**
 * Find an existing folder in downloadDir that starts with the same job number.
 */
function findExistingFolder(downloadDir, jobNumber, fs) {
  try {
    const entries = fs.readdirSync(downloadDir, { withFileTypes: true });
    for (const entry of entries) {
      if (entry.isDirectory() && entry.name.startsWith(jobNumber + ' ')) {
        return path.join(downloadDir, entry.name);
      }
    }
  } catch (e) { /* dir doesn't exist yet */ }
  return null;
}

module.exports = { buildFolderName, extractJobPrefix, findExistingFolder, sanitize };
