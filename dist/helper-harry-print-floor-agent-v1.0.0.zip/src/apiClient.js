/**
 * API Client — axios wrapper with auth header injection
 */
const axios = require('axios');
const config = require('./config');

let _token = null;

function setToken(token) { _token = token; }
function getToken() { return _token; }

function createClient(serverUrl) {
  const baseURL = serverUrl.replace(/\/+$/, '');
  const client = axios.create({
    baseURL,
    timeout: 60000,
    headers: { 'Content-Type': 'application/json' }
  });

  client.interceptors.request.use(cfg => {
    if (_token) cfg.headers.Authorization = `Bearer ${_token}`;
    return cfg;
  });

  return client;
}

module.exports = { createClient, setToken, getToken };
