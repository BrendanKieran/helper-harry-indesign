#!/usr/bin/env node
/**
 * Helper Harry Print Floor Agent
 *
 * Polls the HH cloud API for print-ready jobs and downloads
 * their files to organized local folders on the shop floor.
 *
 * Usage:
 *   hh-agent --setup     Interactive first-run configuration
 *   hh-agent             Start polling (uses saved config)
 *   hh-agent --once      Poll once and exit (for cron/testing)
 */
const chalk = require('chalk');
const fs = require('fs-extra');
const config = require('./config');
const { createClient, setToken } = require('./apiClient');
const { login, ensureAuth } = require('./auth');
const StateTracker = require('./stateTracker');
const { downloadJobFiles } = require('./downloader');

const VERSION = '1.0.0';

function log(msg) {
  const ts = new Date().toLocaleTimeString();
  console.log(chalk.gray(`[${ts}]`) + ' ' + msg);
}

function banner() {
  console.log('');
  console.log(chalk.bold('  Helper Harry Print Floor Agent') + chalk.gray(` v${VERSION}`));
  console.log(chalk.gray('  Downloads print-ready files from the cloud to your shop floor'));
  console.log('');
}

async function pollOnce(client, cfg, stateTracker) {
  const params = { state_name: cfg.watchState };
  if (stateTracker.lastPollTime) params.since = stateTracker.lastPollTime;

  const res = await client.get('/api/workflow/agent/jobs-ready', { params });
  const { jobs, server_time } = res.data;

  if (jobs.length === 0) {
    return 0;
  }

  let totalDownloaded = 0;

  for (const job of jobs) {
    const customer = job.customer_company
      || [job.customer_first_name, job.customer_last_name].filter(Boolean).join(' ')
      || '';
    // Only download PDFs with "OK" or "OKAY" in the filename
    const pendingFiles = job.files.filter(f => {
      if (stateTracker.isFileDownloaded(job.id, f.id, f.version)) return false;
      const name = (f.original_filename || '').toUpperCase();
      if (!name.endsWith('.PDF')) return false;
      if (!/(?:^|[\s_\-.])OK(?:AY)?(?:[\s_\-.]|$)/.test(name.replace(/\.PDF$/, ''))) return false;
      return true;
    });

    if (pendingFiles.length === 0) continue;

    log(chalk.cyan(`${job.job_number}`) + ` ${customer} — ${job.description || ''} (${pendingFiles.length} file${pendingFiles.length !== 1 ? 's' : ''})`);

    const { folderPath, downloadedCount } = await downloadJobFiles(
      client, { ...job, files: pendingFiles }, cfg.downloadDir, stateTracker, cfg.folderTemplate, log
    );
    totalDownloaded += downloadedCount;

    // Optionally complete a state after all files downloaded
    if (cfg.markStateOnDownload && downloadedCount > 0 && !stateTracker.isStateCompleted(job.id)) {
      try {
        await client.post(`/api/workflow/agent/jobs/${job.id}/complete-state`, {
          state_name: cfg.markStateOnDownload
        });
        stateTracker.markStateCompleted(job.id);
        log(`  State "${cfg.markStateOnDownload}" completed`);
      } catch (e) {
        log(`  Warning: couldn't complete state: ${e.message}`);
      }
    }
  }

  stateTracker.lastPollTime = server_time;
  return totalDownloaded;
}

async function sendHeartbeat(client) {
  try {
    await client.post('/api/workflow/agent/heartbeat', { version: VERSION });
  } catch (e) { /* non-fatal */ }
}

async function main() {
  const args = process.argv.slice(2);
  const isSetup = args.includes('--setup');
  const isOnce = args.includes('--once');

  banner();

  // ── Setup mode ──
  if (isSetup) {
    const { config: cfg, password } = await config.interactiveSetup();
    const client = createClient(cfg.serverUrl);

    log('Logging in...');
    try {
      await login(client, cfg.email, password);
      log(chalk.green('Login successful!'));

      // Fetch and display available states
      const statesRes = await client.get('/api/workflow/agent/state-definitions');
      console.log('\n  Available job states:');
      for (const s of statesRes.data) {
        const marker = s.name === cfg.watchState ? chalk.green(' <-- watching') : '';
        console.log(`    ${chalk.bold(s.name)} (${s.display_name})${marker}`);
      }
      console.log('');
    } catch (err) {
      log(chalk.red('Login failed: ' + (err.response?.data?.error || err.message)));
      process.exit(1);
    }

    fs.ensureDirSync(cfg.downloadDir);
    log(`Download directory: ${cfg.downloadDir}`);
    log(chalk.green('Setup complete! Run `hh-agent` to start polling.'));
    process.exit(0);
  }

  // ── Normal polling mode ──
  const cfg = config.load();
  if (!cfg.serverUrl || !cfg.email) {
    log(chalk.yellow('Not configured. Run with --setup first.'));
    process.exit(1);
  }

  const client = createClient(cfg.serverUrl);

  // Restore or prompt for auth
  const authOk = await ensureAuth(client, cfg);
  if (!authOk) {
    log(chalk.yellow('Session expired. Please run --setup or enter password:'));
    const readline = require('readline');
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    const pw = await new Promise(r => rl.question('  Password: ', r));
    rl.close();
    try {
      await login(client, cfg.email, pw);
      log(chalk.green('Login successful'));
    } catch (err) {
      log(chalk.red('Login failed: ' + (err.response?.data?.error || err.message)));
      process.exit(1);
    }
  }

  fs.ensureDirSync(cfg.downloadDir);
  const stateTracker = new StateTracker(cfg.downloadDir);

  log(`Server: ${cfg.serverUrl}`);
  log(`Watching: jobs with "${chalk.bold(cfg.watchState)}" state completed`);
  log(`Download: ${cfg.downloadDir}`);
  log(`Poll interval: ${cfg.pollIntervalMs / 1000}s`);
  if (cfg.markStateOnDownload) log(`Auto-complete: "${cfg.markStateOnDownload}" after download`);
  console.log('');

  // ── Single poll mode ──
  if (isOnce) {
    try {
      const count = await pollOnce(client, cfg, stateTracker);
      log(count > 0 ? chalk.green(`Downloaded ${count} file(s)`) : 'No new files');
      await sendHeartbeat(client);
    } catch (err) {
      log(chalk.red('Poll error: ' + err.message));
      process.exit(1);
    }
    process.exit(0);
  }

  // ── Continuous polling loop ──
  let consecutiveErrors = 0;

  const poll = async () => {
    try {
      const count = await pollOnce(client, cfg, stateTracker);
      if (count > 0) log(chalk.green(`Downloaded ${count} file(s)`));
      consecutiveErrors = 0;
      await sendHeartbeat(client);
    } catch (err) {
      consecutiveErrors++;
      if (err.response?.status === 401 || err.response?.status === 403) {
        log(chalk.red('Authentication expired. Attempting re-login...'));
        try {
          const token = config.loadToken();
          if (token) {
            // Try token refresh — if that fails, user must re-setup
            setToken(token);
            const authOk = await ensureAuth(client, cfg);
            if (!authOk) throw new Error('Token expired');
          }
        } catch (e) {
          log(chalk.red('Re-login failed. Run --setup to reconfigure.'));
          process.exit(1);
        }
      } else {
        log(chalk.red(`Poll error (${consecutiveErrors}): ${err.message}`));
        if (consecutiveErrors >= 10) {
          log(chalk.red('Too many consecutive errors. Exiting.'));
          process.exit(1);
        }
      }
    }
  };

  // Initial poll
  await poll();

  // Subsequent polls on interval
  const timer = setInterval(poll, cfg.pollIntervalMs);

  // Graceful shutdown
  const shutdown = () => {
    log('Shutting down...');
    clearInterval(timer);
    process.exit(0);
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);

  log(chalk.gray('Polling... (Ctrl+C to stop)'));
}

main().catch(err => {
  console.error(chalk.red('Fatal error:'), err.message);
  process.exit(1);
});
