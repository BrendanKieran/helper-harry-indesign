/**
 * Downloader — fetches files from HH API and writes them to local job folders
 */
const fs = require('fs-extra');
const path = require('path');
const { buildFolderName, findExistingFolder } = require('./folderNaming');

async function downloadJobFiles(client, job, downloadDir, stateTracker, folderTemplate, log) {
  // Determine folder path: reuse existing folder if one matches this job number
  let folderPath = findExistingFolder(downloadDir, job.job_number, fs);
  if (!folderPath) {
    const folderName = buildFolderName(job, folderTemplate);
    folderPath = path.join(downloadDir, folderName);
  }

  fs.ensureDirSync(folderPath);

  let downloadedCount = 0;

  for (const file of job.files) {
    // Skip if already downloaded this version
    if (stateTracker.isFileDownloaded(job.id, file.id, file.version)) {
      continue;
    }

    try {
      log(`  Downloading: ${file.original_filename} (v${file.version})`);

      const res = await client.get(
        `/api/workflow/agent/jobs/${job.id}/files/${file.id}/download`,
        { responseType: 'arraybuffer', timeout: 300000 }
      );

      // Write file to job folder
      const filePath = path.join(folderPath, file.original_filename);

      // If file already exists (resubmission), add version suffix
      let finalPath = filePath;
      if (fs.existsSync(filePath) && file.version > 1) {
        const ext = path.extname(file.original_filename);
        const base = path.basename(file.original_filename, ext);
        finalPath = path.join(folderPath, `${base} v${file.version}${ext}`);
      }

      fs.writeFileSync(finalPath, Buffer.from(res.data));

      // Mark downloaded on server
      try {
        await client.patch(`/api/workflow/agent/jobs/${job.id}/files/${file.id}/mark-downloaded`);
      } catch (e) {
        // Non-fatal — file is on disk, just couldn't update server
        log(`  Warning: couldn't mark download on server: ${e.message}`);
      }

      // Record locally
      stateTracker.markFileDownloaded(job.id, job.job_number, folderPath, file.id, {
        version: file.version,
        filename: path.basename(finalPath),
        fileSize: file.file_size
      });

      downloadedCount++;
      log(`  Saved: ${path.basename(finalPath)}`);
    } catch (err) {
      log(`  ERROR downloading ${file.original_filename}: ${err.message}`);
    }
  }

  return { folderPath, downloadedCount };
}

module.exports = { downloadJobFiles };
