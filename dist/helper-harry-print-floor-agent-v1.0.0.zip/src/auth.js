/**
 * Auth — login to Helper Harry, store/refresh JWT token
 */
const config = require('./config');
const { setToken } = require('./apiClient');

async function login(client, email, password) {
  const res = await client.post('/api/auth/login', {
    email,
    password,
    source: 'print-floor-agent'
  });

  if (!res.data?.token) throw new Error('Login failed: no token returned');

  const token = res.data.token;
  setToken(token);
  config.saveToken(token);

  return token;
}

function restoreToken() {
  const token = config.loadToken();
  if (token) {
    setToken(token);
    return true;
  }
  return false;
}

async function ensureAuth(client, cfg) {
  // Try existing token first
  if (restoreToken()) {
    try {
      // Validate token with a lightweight call
      await client.get('/api/workflow/agent/state-definitions');
      return true;
    } catch (err) {
      if (err.response?.status === 401 || err.response?.status === 403) {
        config.clearToken();
      } else {
        throw err; // Network or server error — don't clear token
      }
    }
  }
  return false;
}

module.exports = { login, restoreToken, ensureAuth };
