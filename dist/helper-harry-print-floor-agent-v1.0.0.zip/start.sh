#!/bin/bash
cd "$(dirname "$0")"
node src/index.js
