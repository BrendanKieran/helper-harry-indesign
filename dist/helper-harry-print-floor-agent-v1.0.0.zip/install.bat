@echo off
echo.
echo ===================================
echo Helper Harry Print Floor Agent
echo ===================================
echo.

REM Check Node is installed
where node >/dev/null 2>&1
if errorlevel 1 (
  echo ERROR: Node.js is not installed.
  echo Please install Node.js 18+ from https://nodejs.org and run this again.
  pause
  exit /b 1
)

echo Installing dependencies...
call npm install --production
if errorlevel 1 (
  echo ERROR: npm install failed.
  pause
  exit /b 1
)

echo.
echo Starting first-time setup...
node src\index.js --setup
if errorlevel 1 (
  echo ERROR: Setup failed.
  pause
  exit /b 1
)

echo.
echo Setup complete. Starting agent (press Ctrl+C to stop)...
node src\index.js
